﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class przycisk_pola : MonoBehaviour
{
    private static Graphics G;
    private GameObject gm;
    public struct wspl
    {
        public float x;
        public float y;
    };

    public Queue<wspl> trasa = new Queue<wspl>();

    public bool aktywny = false;
    public bool aktywacja = false;
    void Start()
    {
        G = GameObject.Find("BattleCamera").GetComponent<Graphics>();
    }

    private void OnMouseDown()
    {
        if(aktywacja)
            aktywny = true;
    }
    
    public void AddTrasa(Queue<wspl> que, float x, float y)
    {
        trasa = que;
        wspl w;
        w.x = x;
        w.y = y;
        trasa.Enqueue(w);
    }
    
    public void Aktywacja()
    {
        aktywacja = true;
        Destroy(gm);
        gm = new GameObject();
        gm.transform.position = new Vector2(transform.position.x, transform.position.y);
        SpriteRenderer sr = gm.AddComponent<SpriteRenderer>();
        sr.sprite = G.obrgp;
    }

    public void ClearTrasa()
    {
        trasa.Clear();
        aktywacja = false;
        Destroy(gm);
    }
    
}
