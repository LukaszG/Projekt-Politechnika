﻿using System.Collections;
using UnityEngine.Events;
using UnityEngine.UI;
using UnityEngine;

public class ModWin : MonoBehaviour
{
    public float positionX;
    public float positionY;

    public float mwwidth;
    public float mwheight;

    public Texture i;

    private Rect window;

    private void Start()
    {
        gameObject.SetActive(false);
        
    }

    private void OnGUI()
    {
        
        window = new Rect(positionX, positionY, mwwidth, mwheight);
        window = GUI.ModalWindow(1, window, DoWindow, i);
    }
    

    void DoWindow(int unusedWindowID)
    {
        if (GUI.Button(new Rect(10, 240, 100, 50), "Tak, jestem pewien."))
        {
            

            gameObject.SetActive(false);
        }

    }

    void Fun(int unusedWindowID)
    {

    }

}
