﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine.Events;
using UnityEngine;

public class ModalWindow
{
    private Panel ModalPanel;
    private UnityAction act;
    


    public ModalWindow(Canvas canvas, Sprite texture)
    {
        

        act += Fun;
        ModalPanel = new Panel("Panel", texture);
        ModalPanel.panel.transform.SetParent(canvas.transform, false);
        
    }

    private void Fun()
    {
        
        if (GUI.Button(new Rect(10, 10, 50, 25), "guz"))
        {
            
        }
    }


}

public class Panel
{
    public GameObject panel;
    

    public Panel(string pname, Sprite texture)
    {
        panel.name = pname;

        RTInit(10, 10, (int)texture.textureRect.width, (int)texture.textureRect.height);
        CRIInit(texture);
        
        
    }

    private void RTInit(int x, int y, int width, int height)
    {
        RectTransform RT = panel.AddComponent<RectTransform>();
        RT.position = new Vector2(x, y);
        RT.SetSizeWithCurrentAnchors(RectTransform.Axis.Horizontal, width);
        RT.SetSizeWithCurrentAnchors(RectTransform.Axis.Vertical, height);
    }

    private void CRIInit(Sprite texture)
    {
        CanvasRenderer CR = panel.AddComponent<CanvasRenderer>();
        Image i = panel.AddComponent<Image>();
        i.sprite = texture;
        
    }

    
}