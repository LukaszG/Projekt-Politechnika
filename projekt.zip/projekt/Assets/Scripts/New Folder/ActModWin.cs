﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ActModWin : MonoBehaviour
{
    private ModalWindow mow;
    public Canvas canvas;
    public Sprite texture;
    

    private void Start()
    {
        mow = new ModalWindow(canvas, texture);
    }
	
}

public class ModalWindowAssets : MonoBehaviour
{
    
}