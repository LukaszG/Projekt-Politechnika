﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Przeszkoda : MonoBehaviour
{
    public short tx;
    public short ty;
	
	void Start ()
    {
        float pozx = GetComponent<Transform>().position.x;
        float pozy = GetComponent<Transform>().position.y;
        const float przesunx = 3f;
        const float przesuny = 3f;
        tx = (short)((pozx / 1.25 + przesunx) / 2);
        ty = (short)((pozy / 1.25 + przesuny) / 2);
        Ruch_w_bitwie.mapatab[ty, tx] = true;
    }
}