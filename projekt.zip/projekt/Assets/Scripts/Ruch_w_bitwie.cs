﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class Ruch_w_bitwie : MonoBehaviour
{
    private static BattleMenager BM;
    private static Graphics G;

    private const short HEIGTH = 6;
    private const short WIDTH = 10;
    public Sprite obrgp;
    public Sprite obrpp;
    public Material matpp;
    public float speed = 2f;
    private float pozx;
    private float pozy;
    public float docelpozx;
    public float docelpozy;
    public short tx;
    public short ty;
    private float przesunx = WIDTH - 1;
    private float przesuny = HEIGTH - 1;
    public short zasieg = 3;
    private bool polfaza = true;
    private bool can_move = false;
    private bool zakret = true;
    public short faza = 0;
    public bool aktywacja = false;
    public bool aktywnosc = false;
    private Rigidbody2D rgdbody;
    private Transform trans;
    private Animator anim;
    public GameObject[,] gameobj;
    private GameObject[] Gran_Pola;
    private przycisk_pola[,] prz_p;
    private string[,] przyciski_pol = new string[HEIGTH, WIDTH] { {"przycisk_pola_1_1", "przycisk_pola_1_2", "przycisk_pola_1_3", "przycisk_pola_1_4",
     "przycisk_pola_1_5", "przycisk_pola_1_6", "przycisk_pola_1_7","przycisk_pola_1_8", "przycisk_pola_1_9", "przycisk_pola_1_10" },
     {"przycisk_pola_2_1", "przycisk_pola_2_2", "przycisk_pola_2_3", "przycisk_pola_2_4",
     "przycisk_pola_2_5", "przycisk_pola_2_6", "przycisk_pola_2_7","przycisk_pola_2_8", "przycisk_pola_2_9", "przycisk_pola_2_10" },
     {"przycisk_pola_3_1", "przycisk_pola_3_2", "przycisk_pola_3_3", "przycisk_pola_3_4",
     "przycisk_pola_3_5", "przycisk_pola_3_6", "przycisk_pola_3_7","przycisk_pola_3_8", "przycisk_pola_3_9", "przycisk_pola_3_10" },
     {"przycisk_pola_4_1", "przycisk_pola_4_2", "przycisk_pola_4_3", "przycisk_pola_4_4",
     "przycisk_pola_4_5", "przycisk_pola_4_6", "przycisk_pola_4_7","przycisk_pola_4_8", "przycisk_pola_4_9", "przycisk_pola_4_10" },
     {"przycisk_pola_5_1", "przycisk_pola_5_2", "przycisk_pola_5_3", "przycisk_pola_5_4",
     "przycisk_pola_5_5", "przycisk_pola_5_6", "przycisk_pola_5_7","przycisk_pola_5_8", "przycisk_pola_5_9", "przycisk_pola_5_10" },
     {"przycisk_pola_6_1", "przycisk_pola_6_2", "przycisk_pola_6_3", "przycisk_pola_6_4",
     "przycisk_pola_6_5", "przycisk_pola_6_6", "przycisk_pola_6_7","przycisk_pola_6_8", "przycisk_pola_6_9", "przycisk_pola_6_10" }};
    public static bool[,] mapatab = new bool[HEIGTH, WIDTH] { { false, false, false, false, false, false, false, false, false, false }, { false, false, false, false, false, false, false, false, false, false },
    { false, false, false, false, false, false, false, false, false, false }, { false, false, false, false, false, false, false, false, false, false }, { false, false, false, false, false, false, false, false, false, false },
    { false, false, false, false, false, false, false, false, false, false }}; /////
    // Use this for initialization

    void Start()
    {
        BM = GameObject.Find("BattleCamera").GetComponent<BattleMenager>();
        G = GameObject.Find("BattleCamera").GetComponent<Graphics>();
        obrgp = G.obrgp;
        obrpp = G.obrpp;
        anim = GetComponent<Animator>();
        rgdbody = this.gameObject.AddComponent<Rigidbody2D>();
        rgdbody.gravityScale = 0;
        trans = GetComponent<Transform>();
        pozx = transform.position.x;
        pozy = transform.position.y;
        tx = (short)((pozx / 1.25 + przesunx) / 2);
        ty = (short)((pozy / 1.25 + przesuny) / 2);
        gameobj = new GameObject[HEIGTH, WIDTH];
        prz_p = new przycisk_pola[HEIGTH, WIDTH];
        Gran_Pola = new GameObject[4];
        mapatab[ty, tx] = true;
        faza = 0;

        for (short i = 0; i < HEIGTH; i++)
        {
            for (short o = 0; o < WIDTH; o++)
            {
                gameobj[i, o] = GameObject.Find(przyciski_pol[i, o]);
                prz_p[i, o] = gameobj[i, o].GetComponent<przycisk_pola>();
            }
        }
    }

    // Update is called once per frame
    void Update()
    {
        if (zasieg == faza)
        {
            aktywacja = false;
            polfaza = false;
        }

        if (aktywacja)
        {
            if (((ty != 5) ? (!(mapatab[ty + 1, tx])) : false) && polfaza)
            {
                prz_p[ty + 1, tx].aktywacja = true;
                Gran_Pola[0] = new GameObject();
                Transform tran = Gran_Pola[0].GetComponent<Transform>();
                tran.localScale = new Vector2(2, 2);
                Gran_Pola[0].AddComponent<SpriteRenderer>();
                Gran_Pola[0].transform.position = new Vector2((float)(11.25 - ((9 - (tx)) * 2.5)), (float)(6.25 - ((5 - (ty + 1)) * 2.5)));
                SpriteRenderer spriterend = Gran_Pola[0].GetComponent<SpriteRenderer>();
                spriterend.sprite = obrgp;
            }

            if (((ty != 0) ? (!(mapatab[ty - 1, tx])) : false) && polfaza)
            {
                prz_p[ty - 1, tx].aktywacja = true;
                Gran_Pola[1] = new GameObject();
                Transform tran = Gran_Pola[1].GetComponent<Transform>();
                tran.localScale = new Vector2(2, 2);
                Gran_Pola[1].AddComponent<SpriteRenderer>();
                Gran_Pola[1].transform.position = new Vector2((float)(11.25 - ((9 - (tx)) * 2.5)), (float)(6.25 - ((5 - (ty - 1)) * 2.5)));
                SpriteRenderer spriterend = Gran_Pola[1].GetComponent<SpriteRenderer>();
                spriterend.sprite = obrgp;
            }

            if (((tx != 9) ? (!(mapatab[ty, tx + 1])) : false) && polfaza)
            {
                prz_p[ty, tx + 1].aktywacja = true;
                Gran_Pola[2] = new GameObject();
                Transform tran = Gran_Pola[2].GetComponent<Transform>();
                tran.localScale = new Vector2(2, 2);
                Gran_Pola[2].AddComponent<SpriteRenderer>();
                Gran_Pola[2].transform.position = new Vector2((float)(11.25 - ((9 - (tx + 1)) * 2.5)), (float)(6.25 - ((5 - (ty)) * 2.5)));
                SpriteRenderer spriterend = Gran_Pola[2].GetComponent<SpriteRenderer>();
                spriterend.sprite = obrgp;
            }

            if (((tx != 0) ? (!(mapatab[ty, tx - 1])) : false) && polfaza)
            {
                prz_p[ty, tx - 1].aktywacja = true;
                Gran_Pola[3] = new GameObject();
                Transform tran = Gran_Pola[3].GetComponent<Transform>();
                tran.localScale = new Vector2(2, 2);
                Gran_Pola[3].AddComponent<SpriteRenderer>();
                Gran_Pola[3].transform.position = new Vector2((float)(11.25 - ((9 - (tx - 1)) * 2.5)), (float)(6.25 - ((5 - (ty)) * 2.5)));
                SpriteRenderer spriterend = Gran_Pola[3].GetComponent<SpriteRenderer>();
                spriterend.sprite = obrgp;
            }

            polfaza = false;

            for (short i = 0; i < HEIGTH; i++)
            {
                for (short o = 0; o < WIDTH; o++)
                {
                    if (prz_p[i, o].aktywny)
                    {
                        docelpozx = gameobj[i, o].transform.position.x;/////
                        docelpozy = gameobj[i, o].transform.position.y;///////
                        can_move = true;
                        aktywacja = false;
                        prz_p[i, o].aktywny = false;
                        Destroy(Gran_Pola[0]); ////////
                        Destroy(Gran_Pola[1]); ////////
                        Destroy(Gran_Pola[2]); ////////
                        Destroy(Gran_Pola[3]); ////////
                        for (short n = 0; n < HEIGTH; n++)
                        {
                            for (short m = 0; m < WIDTH; m++)
                            {
                                prz_p[n, m].aktywacja = false;////////
                            }
                        }
                    }
                }
            }
        }
        
        if (can_move)
        {
            BM.canendturn = false;
            BM.turnofftargets(); //
            if (zakret)
            {
                if (pozx < docelpozx)
                {
                    rgdbody.velocity = new Vector2(speed, rgdbody.velocity.y);
                    anim.SetBool("motion", true);
                    if (rgdbody.position.x >= docelpozx)
                    {
                        BM.canendturn = true;
                        print("t");
                        anim.SetBool("motion", false);
                        rgdbody.velocity = new Vector2(0, 0);
                        trans.position = new Vector2(docelpozx, rgdbody.position.y);
                        pozx = docelpozx;
                        zakret = false;
                        mapatab[ty, tx] = false;
                        tx = (short)((pozx / 1.25 + przesunx) / 2);
                        mapatab[ty, tx] = true;
                    }
                }
                else if (pozx > docelpozx)
                {
                    rgdbody.velocity = new Vector2(-speed, rgdbody.velocity.y);
                    anim.SetBool("motion", true);
                    if (rgdbody.position.x <= docelpozx)
                    {
                        BM.canendturn = true;
                        print("t");
                        anim.SetBool("motion", false);
                        rgdbody.velocity = new Vector2(0, 0);
                        trans.position = new Vector2(docelpozx, rgdbody.position.y);
                        pozx = docelpozx;
                        zakret = false;
                        mapatab[ty, tx] = false;
                        tx = (short)((pozx / 1.25 + przesunx) / 2);
                        mapatab[ty, tx] = true;
                    }
                }
                else
                {
                    trans.position = new Vector2(docelpozx, rgdbody.position.y);
                    pozx = docelpozx;
                    zakret = false;

                }
            }
            else if (!zakret)
            {
                if (pozy < docelpozy)
                {
                    rgdbody.velocity = new Vector2(rgdbody.velocity.x, speed);
                    anim.SetBool("motion", true);
                    if (rgdbody.position.y >= docelpozy)
                    {
                        BM.canendturn = true;
                        print("t");
                        anim.SetBool("motion", false);
                        rgdbody.velocity = new Vector2(0, 0);
                        trans.position = new Vector2(rgdbody.position.x, docelpozy);
                        pozy = docelpozy;
                        zakret = true;
                        can_move = false;
                        mapatab[ty, tx] = false;
                        ty = (short)((pozy / 1.25 + przesuny) / 2);
                        mapatab[ty, tx] = true;
                        faza++;
                        aktywacja = true;
                        polfaza = true;
                        if (zasieg == faza)
                        {
                            aktywacja = false;
                            polfaza = false;
                        }
                    }
                }
                else if (pozy > docelpozy)
                {
                    rgdbody.velocity = new Vector2(rgdbody.velocity.x, -speed);
                    anim.SetBool("motion", true);
                    if (rgdbody.position.y <= docelpozy)
                    {
                        BM.canendturn = true;
                        print("t");
                        anim.SetBool("motion", false);
                        rgdbody.velocity = new Vector2(0, 0);
                        trans.position = new Vector2(rgdbody.position.x, docelpozy);
                        pozy = docelpozy;
                        zakret = true;
                        can_move = false;
                        mapatab[ty, tx] = false;
                        ty = (short)((pozy / 1.25 + przesuny) / 2);
                        mapatab[ty, tx] = true;
                        faza++;
                        aktywacja = true;
                        polfaza = true;
                        if (zasieg == faza)
                        {
                            aktywacja = false;
                            polfaza = false;
                        }
                    }
                }
                else
                {
                    BM.canendturn = true;
                    print("t");
                    trans.position = new Vector2(rgdbody.position.x, docelpozy);
                    pozy = docelpozy;
                    zakret = true;
                    can_move = false;
                    BM.turnofftargets(); //
                    faza++;
                    aktywacja = true;
                    polfaza = true;
                    if (zasieg == faza)
                    {
                        aktywacja = false;
                        polfaza = false;
                    }
                }
            }
        }
    }

    /*void OnMouseDown()
    {
        if (aktywnosc)
        {
            
            aktywnosc = false;


            polfaza = true;
            aktywacja = true;
            faza = 0;
        }
    }*/
    public void StartTurnOn()
    {
        polfaza = true;
        aktywacja = true;
        faza = 0;
    }

    public void TurnOn()
    {
        polfaza = true;
        aktywacja = true;
        //BM.turnofftargets();
    }

    public void TurnOff()
    {
        polfaza = false;
        aktywacja = false;
        Destroy(Gran_Pola[0]);
        Destroy(Gran_Pola[1]);
        Destroy(Gran_Pola[2]);
        Destroy(Gran_Pola[3]);
        for (short n = 0; n < HEIGTH; n++)
        {
            for (short m = 0; m < WIDTH; m++)
            {
                prz_p[n, m].aktywacja = false;
            }
        }
    }

    public void turnoff()
    {
        mapatab[ty, tx] = false;
    }
}
