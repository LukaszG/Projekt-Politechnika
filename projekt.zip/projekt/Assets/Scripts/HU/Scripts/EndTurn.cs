﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EndTurn : MonoBehaviour
{
    private BattleMenager BM;

    public void OnMouseDown()
    {
        BM = GameObject.Find("BattleCamera").GetComponent<BattleMenager>();
        print("End turn: " + BM.canendturn);
        if (BM.canendturn)
        {
            BM.changeSide();
        }
    }
}
