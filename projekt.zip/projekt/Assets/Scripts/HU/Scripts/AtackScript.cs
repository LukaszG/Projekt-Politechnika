﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AtackScript : MonoBehaviour
{
    private static BattleMenager BM;
    private int ID;

    public void setID(int v)
    {
        ID = v;
    }

    public int getID()
    {
        return ID;
    }

    public void Start()
    {
        BM = GameObject.Find("BattleCamera").GetComponent<BattleMenager>();
    }
    /*
    public void Update()
    {
        if(i)
        {
            dt += (int)(Time.deltaTime * 1000);
            print(dt);
        }

        if (BM.AllUnits[ID].getCanBeAtacked() && BM.AllUnits[BM.getActiveID()].getIsChoosen() && (dt >= 500) &&(BM.AllUnits[ID].getNumber() > 0))
        {
            BM.printMSG("Atak poczatek");
            BM.setTargetID(ID);
            BM.AllUnits[BM.getActiveID()].attack(ID); //HB.gettID() / ID
            BM.printMSG("Atak koniec");
            i = false;
            dt = 0;

            if (BM.AllUnits[ID].getNumber() == 0)
            {
                
                Animator A = BM.InBattleUnits[ID].GetComponent<Animator>();
                A.SetBool("death", true);
                BM.turnofftargets();

                i = true;
            }
        }

        if(BM.AllUnits[ID].getNumber() == 0 && (dt >= 500))
        {
            i = false;
            dt = 0;


            BM.AllHeroes[BM.AllUnits[ID].getHeroName()].Team.Remove(ID);
            BM.AllUnits.Remove(ID);

            BM.changeSide();

            BM.Delete(ID);
        }
    }
    */


    public void OnMouseDown()
    {
        if (BM.AllUnits[ID].getCanBeAtacked() && BM.AllUnits[BM.getActiveID()].getIsChoosen())
        {
            BM.setTargetID(ID);

            Animator anim = BM.InBattleUnits[BM.getActiveID()].GetComponent<Animator>();
            anim.SetBool("atack", true);
        }
    }
}
