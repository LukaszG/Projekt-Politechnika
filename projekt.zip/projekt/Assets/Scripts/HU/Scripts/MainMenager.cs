﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class MainMenager : MonoBehaviour
{
    public static short side;
    public static string choosenhero;

    public static SortedList<int, Unit> AllUnits = new SortedList<int, Unit>();
    public static SortedList<string, Hero> AllHero = new SortedList<string, Hero>();    

    //constants
    private const short SIDE1 = 1;
    private const short SIDE2 = 2;


    //side functions

    public static short getSide()
    {
        return side;
    }

    public void changeSide()
    {
        if (side == SIDE1)
            side = SIDE2;
        else
            side = SIDE1;
    }

    //hero functions
    public static void setHeroName(string n)
    {
        choosenhero = n;
    }

    public static string getHeroName()
    {
        return choosenhero;
    }
}
