﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEditor;
using UnityEngine;

public class BattleMenager : MonoBehaviour
{
    private static Graphics G;
    private static GameObject Unit_Profile;
    private static GameObject Unit_View;
    private static GameObject M0B;
    private static GameObject M0BT;
    private static GameObject M1B;
    private static GameObject M1BT;
    private static GameObject M2B;
    private static GameObject M2BT;
    private static GameObject M3B;
    private static GameObject M3BT;

    //colections
    public SortedList<int, Unit> AllUnits = new SortedList<int, Unit>();
    public SortedList<string, Hero> AllHeroes = new SortedList<string, Hero>();
    public SortedList<int, GameObject> InBattleUnits = new SortedList<int, GameObject>();
    public SortedList<int, GameObject> Boarder = new SortedList<int, GameObject>();

    //heroes & units data
    private string ahero;
    private string dhero;
    private string AThero;
    private string DEFhero;

    private int activeID = 0;
    private int targetID;

    //location data
    private const float XSCALE = 2.5f;
    private const float YSCALE = 2.5f;

    private const short width = 10;
    private const short height = 6;

    private const float LDRX = -((width/2 - 1) * XSCALE) - 1.25f;
    private const float LDRY = -((height / 2 - 1) * XSCALE) - 1.25f;

    private short l = 1;

    //turn data
    private int turnnumber = 1;
    public bool canendturn = true; 



    //activity & turn functions
    public void changeSide()
    {
        for (short i = 0; i < 4 && AllUnits[activeID].moveset[i] != null; i++)
        {
            switch (i)
            {
                case 0:
                    M0B.SetActive(false);
                    break;
                case 1:
                    M1B.SetActive(false);
                    break;
                case 2:
                    M2B.SetActive(false);
                    break;
                case 3:
                    M3B.SetActive(false);
                    break;
            }
        }
        Unit_Profile.SetActive(false);
        
        {
            string n = ahero;
            ahero = dhero;
            dhero = n;
        }

        foreach (int i in AllHeroes[ahero].Team.Values)
        {
            Uncheck(i);
        }

        if (activeID != 0)
        {
            AllUnits[activeID].setChoosable(false);
            AllUnits[activeID].setIsChoosen(false);
            InBattleUnits[activeID].GetComponent<Ruch_w_bitwie>().TurnOff();
        }
        {
            int id = 0;
            bool v = true;

            while(v)
            {
                if (AllHeroes[ahero].getLA() == 1)
                {
                    foreach (int i in AllHeroes[ahero].Team.Values)
                        AllUnits[i].setChoosable(true);
                }

                short a = 0;
                short s = 0;
                

                foreach (int i in AllHeroes[ahero].Team.Values)
                {
                    if (AllUnits[i].getChoosable())
                    {
                        if (s < AllUnits[i].getSpeed())
                        {
                            s = AllUnits[i].getSpeed();
                            id = i;
                            v = false;
                            
                        }

                        a++;
                    }
                }

                AllHeroes[ahero].setLA(a);
            }

            activeID = id;
        }

        AllUnits[activeID].setIsChoosen(true);
        InBattleUnits[activeID].GetComponent<Ruch_w_bitwie>().faza = 0;
        InBattleUnits[activeID].GetComponent<Ruch_w_bitwie>().TurnOn();
        SetUnitProfile();

        GameObject.Find("ActivePlayer").GetComponent<Text>().text = AllHeroes[ahero].getON();

        turnnumber++;
        GameObject.Find("TurnNumber").GetComponent<Text>().text = ((turnnumber +1)/2).ToString();
    }


    //heroes & units functions
    public void searchtarget(short trange, float arange)
    {
        float posx = InBattleUnits[activeID].transform.position.x;
        float posy = InBattleUnits[activeID].transform.position.y;

        foreach (GameObject go in InBattleUnits.Values)
        {
            AllUnits[go.GetComponent<AtackScript>().getID()].setCanBeAtacked(false);
            Uncheck(go.GetComponent<AtackScript>().getID());
        }

        foreach(int i in AllHeroes[dhero].Team.Values)
        {
            GameObject go = InBattleUnits[i];

            float posenemyx = go.transform.position.x;
            float posenemyy = go.transform.position.y;
            //ciosy puste w środku; ich obszar atakowany zależy oo jak duży zasięg obejmują
            switch(trange)
            {
                case 1:
                    {

                    }
                    break;
                case 5:
                    {
                        float range = arange * XSCALE;
                        if (((warbez(posenemyx - posx)) <= range) && (((warbez(posenemyy - posy)) <= range)))
                            Mark(i);
                    }
                    break;
            }
        }
    }

    public void searchtarget()
    {
        float posx = InBattleUnits[activeID].transform.position.x;
        float posy = InBattleUnits[activeID].transform.position.y;

        float zasieg = AllUnits[activeID].getARange() * XSCALE;

        //short tr = AllUnits[activeID].getTRange();

        int lc = 0;
        short t1 = 0;
        short t2 = 0;

        foreach (GameObject go in InBattleUnits.Values)
        {
            AllUnits[go.GetComponent<AtackScript>().getID()].setCanBeAtacked(false);
            Uncheck(go.GetComponent<AtackScript>().getID());
        }

        short tr = 0;

        foreach (/*GameObject gb in InBattleUnits.Values*/int i in AllHeroes[dhero].Team.Values)
        {
            GameObject go = InBattleUnits[i];

            float pozwrogax = go.transform.position.x;
            float pozwrogay = go.transform.position.y;

            print("lc = " + lc + "\t t1 = " + t1 + "\t t2 = " + t2);

            // dla jednostek, które atakują wokół siebie
            if (tr == 2)
            {
                if (((((pozwrogax - posx) >= 0) ? (pozwrogax - posx) : (posx - pozwrogax)) + (((pozwrogay - posy) >= 0) ? (pozwrogay - posy) : (posy - pozwrogay))) <= zasieg)
                {
                    //AllUnits[gb.GetComponent<UScript>().getID()].setCanBeAttacked(true);
                    Mark(i);
                    lc++;
                    t2 = 2;
                }

                /*
                if((zasieg == 1) && ((pozwrogax == posx - 2.5f) || (pozwrogax == posx + 2.5f)) && ((pozwrogay == posy - 2.5f) || (pozwrogay == posy + 2.5f)))
                {
                    Mark(i);
                    lc++;
                    t2 = 2;
                }
                */
                if (zasieg == 2.5f)
                {
                    if (((posx + XSCALE) == pozwrogax) && ((posy + YSCALE) == pozwrogay))
                        Mark(i);                          
                    if (((posx - XSCALE) == pozwrogax) && ((posy - YSCALE) == pozwrogay))
                        Mark(i);                            
                    if (((posx + XSCALE) == pozwrogax) && ((posy - YSCALE) == pozwrogay))
                        Mark(i);                             
                    if (((posx - XSCALE) == pozwrogax) && ((posy + YSCALE) == pozwrogay))
                        Mark(i);
                    lc++;
                    t2 += 1;
                }
            }
            else
            // dla jednostek, które atakują tylko w pionie i poziomie
            if (tr == 1)
            {
                if ((((((pozwrogax - posx) >= 0) ? (pozwrogax - posx) : (posx - pozwrogax)) <= zasieg) && (pozwrogay == posy)) || (((((pozwrogay - posy) >= 0) ? (pozwrogay - posy) : (posy - pozwrogay)) <= zasieg) && (pozwrogax == posx)))
                {
                    //AllUnits[gb.GetComponent<UScript>().getID()].setCanBeAttacked(true);
                    Mark(i);
                    lc++;
                    t1 = 1;
                }
            }
        }

        print("Przeszukano! Liczba możliwych celow: " + lc + "\n t1 = " + t1 + "\t t2 = " + t2);
    }

    public void turnofftargets()
    {
        if (activeID != 0)
        {
            AllUnits[activeID].setNMove(-1);

            foreach (int i in AllHeroes[dhero].Team.Values)
            {
                Uncheck(i);
            }
        }
    }

    //ID functions
    public int getActiveID()
    {
        return activeID;
    }

    public void setTargetID(int v)
    {
        targetID = v;
    }

    public int getTargetID()
    {
        return targetID;
    }


    //menaging functions
    public void clearMenager()
    {
        foreach (GameObject gb in InBattleUnits.Values)
        {
            Destroy(gb);
        }
        l = 1;
        activeID = 0;
    }

    public void createunits(int v, short s) //
    {

        GameObject go = new GameObject();

        /*Rigidbody2D R2D = go.AddComponent<Rigidbody2D>();
        R2D.gravityScale = 0;*/
        AtackScript AS = go.AddComponent<AtackScript>();
        AS.setID(v);

        BoxCollider2D bc = go.AddComponent<BoxCollider2D>();
        bc.isTrigger = true;
        

        SpriteRenderer SR = go.AddComponent<SpriteRenderer>();

        Animator anim = go.AddComponent<Animator>();

        switch (AllUnits[v].getUnitTypeName())
        {
            case "TANK":
                {
                    SR.sprite = G.czolg;
                    anim.runtimeAnimatorController = G.PBanim;
                }
                break;

            case "CAVALERYMAN":
                {
                    SR.sprite = G.kawalerzysta;
                    anim.runtimeAnimatorController = G.PBanim;
                }
                break;

            case "RIFLEMAN":
                {
                    SR.sprite = G.strzelec;
                    anim.runtimeAnimatorController = G.SBanim;
                }
                break;

            case "FLAME_THROWER":
                {
                    SR.sprite = G.miotaczplomieni;
                    anim.runtimeAnimatorController = G.PBanim;
                }
                break;

            case "INFATRY":
                {
                    SR.sprite = G.piechota;
                    anim.runtimeAnimatorController = G.PBanim;
                }
                break;

            case "PIKEMAN":
                {
                    SR.sprite = G.pikinier;
                    anim.runtimeAnimatorController = G.PBanim;
                }
                break;
        }
                

        float px;
        if (s == 1)
            px = LDRX;
        else
        {
            px = -LDRX;
            SR.flipX = true;
        }
        
        go.transform.position = new Vector2(px, LDRY + l++ * YSCALE);

        Ruch_w_bitwie rwb = go.AddComponent<Ruch_w_bitwie>();
        rwb.zasieg = AllUnits[v].getWRange();

        

        InBattleUnits.Add(v, go);
    }

    public void Delete(int t)
    {
        InBattleUnits[t].GetComponent<Ruch_w_bitwie>().turnoff();
        Destroy(InBattleUnits[t]);
        InBattleUnits.Remove(t);
    }

    public void load(string an, string dn)
    {
        Unit_Profile = GameObject.Find("Unit_Profile");
        Unit_View = GameObject.Find("Unit_View");
        M0B = GameObject.Find("Move_0_Button");
        M0B.SetActive(false);
        M0BT = GameObject.Find("Move_0_Button_Text");
        M1B = GameObject.Find("Move_1_Button");
        M1B.SetActive(false);
        M1BT = GameObject.Find("Move_1_Button_Text"); ;
        M2B = GameObject.Find("Move_2_Button");
        M2B.SetActive(false);
        M2BT = GameObject.Find("Move_2_Button_Text"); ;
        M3B = GameObject.Find("Move_3_Button");
        M3B.SetActive(false);
        M3BT = GameObject.Find("Move_3_Button_Text"); ;

        G = GameObject.Find("BattleCamera").GetComponent<Graphics>();

        ahero = an;
        dhero = dn;

        GameObject.Find("ActivePlayer").GetComponent<Text>().text = AllHeroes[ahero].getON();
        GameObject.Find("ActivePlayer").SetActive(true);
        GameObject.Find("TurnNumber").GetComponent<Text>().text = turnnumber.ToString();

        foreach (int i in AllHeroes[an].Team.Values)
            createunits(i, 1);

        l = 1;

        foreach (int i in AllHeroes[dn].Team.Values)
            createunits(i, 2);

        l = 1;
        

        {
            int id = 0;
            bool v = true;

            while (v)
            {
                if (AllHeroes[ahero].getLA() == 1)
                {
                    foreach (int i in AllHeroes[ahero].Team.Values)
                        AllUnits[i].setChoosable(true);
                }

                short a = 0;
                short s = 0;


                foreach (int i in AllHeroes[ahero].Team.Values)
                {
                    if (AllUnits[i].getChoosable())
                    {
                        if (s < AllUnits[i].getSpeed())
                        {
                            s = AllUnits[i].getSpeed();
                            id = i;
                            v = false;

                        }

                        a++;
                    }
                }

                AllHeroes[ahero].setLA(a);
            }

            activeID = id;
        }

        AllUnits[activeID].setIsChoosen(true);
        InBattleUnits[activeID].GetComponent<Ruch_w_bitwie>().faza = 0;
        InBattleUnits[activeID].GetComponent<Ruch_w_bitwie>().TurnOn();
        SetUnitProfile();
    }

    public void Mark(int i)
    {
        AllUnits[i].setCanBeAtacked(true);
        GameObject boardertarget = new GameObject();

        boardertarget.transform.position = new Vector2(InBattleUnits[i].transform.position.x, InBattleUnits[i].transform.position.y);
        SpriteRenderer sr = boardertarget.AddComponent<SpriteRenderer>();
        sr.sprite = G.Sprbt;
        Boarder.Add(i, boardertarget);
    }

    public void SetUnitProfile()
    {
        {
            Unit_Profile.SetActive(true);
            SpriteRenderer SR = Unit_View.GetComponent<SpriteRenderer>();
            

            switch (AllUnits[activeID].getUnitTypeName())
            {
                case "TANK":
                    SR.sprite = G.czolg;
                    break;

                case "CAVALERYMAN":
                    SR.sprite = G.kawalerzysta;
                    break;

                case "RIFLEMAN":
                    SR.sprite = G.strzelec;
                    break;

                case "FLAME_THROWER":
                    SR.sprite = G.miotaczplomieni;
                    break;

                case "INFATRY":
                    SR.sprite = G.piechota;
                    break;

                case "PIKEMAN":
                    SR.sprite = G.pikinier;
                    break;
            }
        }

        {
            Text t = GameObject.Find("Unit_Name").GetComponent<Text>();
            t.text = AllUnits[activeID].getUnitTypeName();
        }

        for(short i = 0;i < 4 && AllUnits[activeID].moveset[i] != null; i++)
        {
            switch(i)
            {
                case 0:
                    M0B.SetActive(true);
                    M0B.GetComponent<MBScript>().nmove = i;
                    break;
                case 1:
                    M1B.SetActive(true);
                    M1B.GetComponent<MBScript>().nmove = i;
                    break;
                case 2:
                    M2B.SetActive(true);
                    M2B.GetComponent<MBScript>().nmove = i;
                    break;
                case 3:
                    M3B.SetActive(true);
                    M3B.GetComponent<MBScript>().nmove = i;
                    break;
            }

            GameObject MBT = GameObject.Find("Move_" + i + "_Button_Text");
            MBT.GetComponentInParent<Text>().text = AllUnits[activeID].moveset[i].getMoveName();
        }
    }

    public void Uncheck(int i)
    {
        if (Boarder.ContainsKey(i))
        {
            Destroy(Boarder[i]);
            Boarder.Remove(i);
        }

    }

    //other functions
    public void printMSG(string str)
    {
        print(str);
    }

    private float warbez(float l)
    {
        if (l < 0)
            return -l;
        else
            return l;
    }
}

/*
BŁĘDY i RZECZY DO ZROBIENIA:
- KONIEC BITWY I RESET
*/
