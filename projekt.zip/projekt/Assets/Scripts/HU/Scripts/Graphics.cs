﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Graphics : MonoBehaviour
{
    //Sprits
    public Sprite obrgp; //ruch
    public Sprite obrpp; //atak
    public Sprite Sprbt; //atak
    public Sprite czolg;
    public Sprite kawalerzysta;
    public Sprite strzelec;
    public Sprite piechota;
    public Sprite miotaczplomieni;
    public Sprite pikinier;

    //Animator
    public RuntimeAnimatorController PBanim;
    public RuntimeAnimatorController SBanim;

    public Sprite getSprtbt()
    {
        return Sprbt;
    }

    public Sprite getSprite(string s = "tank")
    {
        return czolg;
    }
}
