﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MBScript : MonoBehaviour
{
    private static BattleMenager BM;
    public short nmove;

    public void OnMouseDown()
    {
        BM = GameObject.Find("BattleCamera").GetComponent<BattleMenager>();
        BM.AllUnits[BM.getActiveID()].moveset[nmove].searchtarget();
        BM.AllUnits[BM.getActiveID()].setNMove(nmove);
    }
}
