﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EndGame : MonoBehaviour
{
    private BattleMenager BM;

    public void OnMouseDown()
    {
        BM = GameObject.Find("BattleCamera").GetComponent<BattleMenager>();
        BM.clearMenager();
    }

}
