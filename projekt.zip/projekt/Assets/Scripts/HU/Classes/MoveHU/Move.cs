﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Move
{
    public string movename;

    public static BattleMenager BM = GameObject.Find("BattleCamera").GetComponent<BattleMenager>();

    public enum rtypes : short { CIRCLE = 1, RING, PLUS, PLUSWITHOUTCROSSONG, SQUARE, EMPTYSQUARE};
    public short trange;

    public virtual void useMove(int uID, int tID)
    {

    }

    public virtual void searchtarget()
    {
        
    }

    public virtual string getMoveName()
    {
        return movename;
    }
}
