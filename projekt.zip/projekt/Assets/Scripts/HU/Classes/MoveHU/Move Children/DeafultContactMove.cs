﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DeafultContactMove : Move
{
    string movename = "DeafultContactMove";
    short trange = (short)rtypes.SQUARE;

    public override void useMove(int uID, int tID)
    {
        BM.AllUnits[tID].nhealthDecrease(BM.AllUnits[uID].getCDamage());
    }

    public override void searchtarget()
    {
        BM.searchtarget(trange, 1.0f);
    }

    public override string getMoveName()
    {
        return movename;
    }
}
