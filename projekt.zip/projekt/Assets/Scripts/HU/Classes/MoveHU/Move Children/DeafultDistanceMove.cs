﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DeafultDistanceMove : Move
{
    string movename = "DeafultDistanceMove";
    short trange = (short)rtypes.SQUARE;

    public override void useMove(int uID, int tID)
    {
        BM.AllUnits[tID].nhealthDecrease(BM.AllUnits[uID].getDDamage());
    }

    public override void searchtarget()
    {
        BM.searchtarget(trange, BM.AllUnits[BM.getActiveID()].getARange());
    }

    public override string getMoveName()
    {
        return movename;
    }
}