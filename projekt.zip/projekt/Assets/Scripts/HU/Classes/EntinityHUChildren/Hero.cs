﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Hero
{
    //main data
    private string heroname;
    private string ownername;

    private static BattleMenager BM = GameObject.Find("BattleCamera").GetComponent<BattleMenager>();

    //team data
    public SortedList<int, int> Team = new SortedList<int, int>();
    short lastavaible = 0;

    public Hero(string hn, string on)
    {
        heroname = hn;
        ownername = on;
    }


    //main functions
    public string getON()
    {
        return ownername;
    }


    //team functions
    public short getLA()
    {
        return lastavaible;
    }

    public void setLA(short v)
    {
        lastavaible = v;
    }

    public void recruit(short t, int n)
    {
        Unit u = new Unit(t, n, heroname);
        Team.Add(u.getID(), u.getID());
        BM.AllUnits.Add(u.getID(), u);

    }
}
