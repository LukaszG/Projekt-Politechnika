﻿using System;
using System.Threading;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class Unit
{
    //main data
    private string unittypename;
    private string heroname;
    private string ownernick;
    private int ID;

    //other maybe main data
    private static BattleMenager BM = GameObject.Find("BattleCamera").GetComponent<BattleMenager>();
    private static int last_ID = 1;
    private enum utype : short {TANK = 1, CAVALERYMAN, RIFLEMAN, FLAME_THROWER, INFATRY, PIKEMAN};

    //motion data
    private short speed;
    private short wrange;

    //health data
    private int uhealth;
    private int mhealth;
    private int nhealth;

    //activity data
    private bool choosable = true;
    private bool ischoosen = false;

    //atack data
    public Move[] moveset = new Move[4];
    private short uddamage; //distance damage
    private short ucdamage; //contact damage
    private int number;
    private float arange;
    private bool canatack;
    private bool canbeatacked = false;
    private static short nmove = -1;
    


    //constructor class
    public Unit(short t, int n, string hn)
    {
        heroname = hn;
        number = n;
        ownernick = BM.AllHeroes[hn].getON();
        ID = createID();
        moveset[0] = null;
        moveset[1] = null;
        moveset[2] = null;
        moveset[3] = null;
        
        if (t == (short)utype.TANK)
        {
            unittypename = "TANK";
            
            speed = 1;
            wrange = 3;
            uddamage = 6;
            ucdamage = 9;
            arange = 3;

            uhealth = 10;
            mhealth = n * uhealth;
            nhealth = n * uhealth;

            moveset[0] = new DeafultDistanceMove();
            moveset[1] = new DeafultContactMove();
        }
        else if (t == (short)utype.CAVALERYMAN)
        {
            unittypename = "CAVALERYMAN";

            speed = 6;
            wrange = 7;
            uddamage = 0;
            ucdamage = 4;
            arange = 1;

            uhealth = 6;
            mhealth = n * uhealth;
            nhealth = n * uhealth;

            moveset[0] = new DeafultContactMove();
        }
        else if (t == (short)utype.RIFLEMAN)
        {
            unittypename = "RIFLEMAN";

            speed = 5;
            wrange = 4;
            uddamage = 5;
            ucdamage = 1;
            arange = 5;

            uhealth = 3;
            mhealth = n * uhealth;
            nhealth = n * uhealth;

            moveset[0] = new DeafultDistanceMove();
            moveset[1] = new DeafultContactMove();
        }
        else if (t == (short)utype.FLAME_THROWER)
        {
            unittypename = "FLAME_THROWER";

            speed = 3;
            wrange = 4;
            uddamage = 0;
            ucdamage = 5;
            arange = 1;

            uhealth = 4;
            mhealth = n * uhealth;
            nhealth = n * uhealth;

            moveset[0] = new DeafultContactMove();
        }
        else if (t == (short)utype.INFATRY)
        {
            unittypename = "INFATRY";

            speed = 2;
            wrange = 5;
            uddamage = 0;
            ucdamage = 3;
            arange = 1;

            uhealth = 5;
            mhealth = n * uhealth;
            nhealth = n * uhealth;

            moveset[0] = new DeafultContactMove();
        }
        else if (t == (short)utype.PIKEMAN)
        {
            unittypename = "PIKEMAN";

            speed = 4;
            wrange = 4;
            uddamage = 0;
            ucdamage = 3;
            arange = 1;

            uhealth = 4;
            mhealth = n * uhealth;
            nhealth = n * uhealth;

            moveset[0] = new DeafultContactMove();
        }
    }



    //main function
    public string getUnitTypeName()
    {
        return unittypename;
    }

    public int getNumber()
    {
        return number;
    }

    public string getHeroName()
    {
        return heroname;
    }


    //activity function
    public bool getChoosable()
    {
        return choosable;
    }

    public void setChoosable(bool v)
    {
        choosable = v;
    }

    public bool getIsChoosen()
    {
        return ischoosen;
    }

    public void setIsChoosen(bool v)
    {
        ischoosen = v;
    }

    //atack functions
   
    public void attack(int t)
    {
        //////////////
        
        if (nmove >= 0)
            moveset[nmove].useMove(ID, t);
        
        /*
        if (BM.AllUnits[t].getNumber() == 0)
        {
            BM.turnofftargets();
            Animator A = BM.InBattleUnits[t].GetComponent<Animator>();
            A.SetBool("death", true);
            A.SetBool("death", false);
            Thread.Sleep(1000);
            BM.AllHeroes[BM.AllUnits[t].getHeroName()].Team.Remove(t);
            BM.AllUnits.Remove(t);
            BM.Delete(t);
        }
        */

    }
    

    public float getARange()
    {
        return arange;
    }

    public void setCanBeAtacked(bool b)
    {
        canbeatacked = b;
    }

    public bool getCanBeAtacked()
    {
        return canbeatacked;
    }

    public int getCDamage()
    {
        return number * ucdamage;
    }

    public int getDDamage()
    {
        return number * uddamage;
    }

    public void setNMove(short v)
    {
        nmove = v;
    }


    //health functions
    public void nhealthDecrease(int taken_damage)
    {
        int lostnumber;

        if (taken_damage <= nhealth)
        {
            nhealth -= taken_damage;
            lostnumber = taken_damage / uhealth;
            number -= lostnumber;
        }
        else
        {
            nhealth = 0;
            number = 0;
        }

        //BM.InBattleUnits[ID].GetComponent<UScript>().setHP(nhealth);

        //BM.printMSG("Zmiejszono życie do " + nhealth + ". Liczba jednostek " + number);
    }

    public int getNNHP()
    {
        return nhealth;
    }


    //ID function
    public int createID()
    {
        int id;

        if (BM.AllUnits.ContainsKey(++last_ID) == false)
        {
            id = last_ID;
        }
        else
        {
            while (BM.AllUnits.ContainsKey(++last_ID) != false)
            {
            }
            id = last_ID;
        }

        return id;
    }

    public int getID()
    {
        return ID;
    }


    //motion function
    public short getWRange()
    {
        return wrange;
    }

    public short getSpeed()
    {
        return speed;
    }
}

/*
 * mnożnik poziomów - przekazywanie wartość równej poziomowi która stanowi możnik statystyk
 * 
*/