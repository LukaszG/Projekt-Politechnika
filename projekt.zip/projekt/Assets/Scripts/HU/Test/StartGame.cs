﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StartGame : MonoBehaviour
{
    public GameObject StartPanel;
    public void OnMouseDown()
    {
        BattleMenager BM = GameObject.Find("BattleCamera").GetComponent<BattleMenager>();
        BM.AllHeroes.Add("hero1", new Hero("hero1", "Pierwszy"));
        print("New hero has been created!");
        
        BM.AllHeroes.Add("hero2", new Hero("hero2", "Drugi"));
        print("New hero has been created!");

        string n = "hero1";
        for (short i = 0; i < 4; i++)
        {
            System.Random rd = new System.Random(System.DateTime.Now.Millisecond);
            short rdtype = (short)rd.Next(1, 7);

            switch (rdtype)
            {
                case 1:
                    BM.AllHeroes[n].recruit(1, 100);
                    break;

                case 2:
                    BM.AllHeroes[n].recruit(2, 100);
                    break;

                case 3:
                    BM.AllHeroes[n].recruit(3, 100);
                    break;

                case 4:
                    BM.AllHeroes[n].recruit(4, 100);
                    break;

                case 5:
                    BM.AllHeroes[n].recruit(5, 100);
                    break;

                case 6:
                    BM.AllHeroes[n].recruit(6, 100);
                    break;
            }

            print("New units has been recruited!");
        }

        n = "hero2";
        for (short i = 0; i < 4; i++)
        {
            System.Random rd = new System.Random(System.DateTime.Now.Millisecond);
            short rdtype = (short)rd.Next(1, 7);

            switch (rdtype)
            {
                case 1:
                    BM.AllHeroes[n].recruit(1, 100);
                    break;

                case 2:
                    BM.AllHeroes[n].recruit(2, 100);
                    break;

                case 3:
                    BM.AllHeroes[n].recruit(3, 100);
                    break;

                case 4:
                    BM.AllHeroes[n].recruit(4, 100);
                    break;

                case 5:
                    BM.AllHeroes[n].recruit(5, 100);
                    break;

                case 6:
                    BM.AllHeroes[n].recruit(6, 100);
                    break;
            }

            print("New units has been recruited!");
        }

        print("Battle Scene soon will be loaded!");
        BM.load("hero1", "hero2");
        print("Battle Scene has been loaded!");
        StartPanel.SetActive(false);
    }
}
