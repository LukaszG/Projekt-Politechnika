﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class mapa_bitwy : MonoBehaviour
{
    public bool aktywny;
    public float docx;
    public float docy;
	// Use this for initialization
	void Start ()
    {
        aktywny = false;
    }
	
	// Update is called once per frame
	void Update ()
    {
		
	}

    void SetX(float dx)
    {
        docx = dx;
    }

    void SetY(float dy)
    {
        docy = dy;
    }
}
