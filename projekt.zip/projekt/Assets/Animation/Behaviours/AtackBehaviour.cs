﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AtackBehaviour : StateMachineBehaviour {

    // OnStateEnter is called when a transition starts and the state machine starts to evaluate this state
    //override public void OnStateEnter(Animator animator, AnimatorStateInfo stateInfo, int layerIndex) {
    //
    //}

    // OnStateUpdate is called on each Update frame between OnStateEnter and OnStateExit callbacks
    override public void OnStateUpdate(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    {
        if (stateInfo.normalizedTime >= 1)
        {
            animator.SetBool("atack", false);
        }
    }

    // OnStateExit is called when a transition ends and the state machine finishes evaluating this state
    override public void OnStateExit(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    {
        BattleMenager BM = GameObject.Find("BattleCamera").GetComponent<BattleMenager>();
        int ID = BM.getTargetID();
        
        BM.printMSG("Atak poczatek");
        BM.AllUnits[BM.getActiveID()].attack(ID); //HB.gettID() / ID
        BM.printMSG("Atak koniec");

        if (BM.AllUnits[ID].getNumber() == 0)
        {
            BM.turnofftargets();
            Animator A = BM.InBattleUnits[ID].GetComponent<Animator>();
            A.SetBool("death", true);
        }
        else
            BM.changeSide();
    }

    // OnStateMove is called right after Animator.OnAnimatorMove(). Code that processes and affects root motion should be implemented here
    //override public void OnStateMove(Animator animator, AnimatorStateInfo stateInfo, int layerIndex) {
    //
    //}

    // OnStateIK is called right after Animator.OnAnimatorIK(). Code that sets up animation IK (inverse kinematics) should be implemented here.
    //override public void OnStateIK(Animator animator, AnimatorStateInfo stateInfo, int layerIndex) {
    //
    //}
}
