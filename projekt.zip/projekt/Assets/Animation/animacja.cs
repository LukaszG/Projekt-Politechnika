﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Video;
using UnityEngine.UI;


public class animacja : MonoBehaviour {
    public VideoPlayer vidplr;
	// Use this for initialization
	void Start () {
        vidplr = GetComponent<VideoPlayer>();
	}
	
	// Update is called once per frame
	void Update () {
        vidplr.Play();
	}
}
